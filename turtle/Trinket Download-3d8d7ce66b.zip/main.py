import turtle

turtle.pencolor('purple')
turtle.pensize(5)
turtle.speed(50)
turtle.dot(15)


colors = ['blue', 'red', 'orange', 'green', 'purple', 'pink']
petals = 25
color=0


for i in range(petals):
  if color < len(colors):
    turtle.pencolor(colors[color])
    color+=1
  else:
    color = 0
  turtle.right(360/petals)
  turtle.forward(80)
  turtle.backward(80)
  
  
turtle.dot(30)
